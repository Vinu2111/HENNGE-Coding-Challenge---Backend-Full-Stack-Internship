import sys

def sum_of_squares(test_cases, results=[]):
    if not test_cases:
        print("\n".join(map(str, results)))
        return
    
    x = int(test_cases.pop(0))
    numbers = list(map(int, test_cases.pop(0).split()))
    result = sum(n ** 2 for n in numbers if n >= 0)
    
    results.append(result)
    sum_of_squares(test_cases, results)

def main():
    """
    HENNGE Coding Challenge - Backend/Full-Stack Internship
    
    This script reads multiple test cases from standard input, processes the data,
    and calculates the sum of squares of non-negative integers as per the problem statement.
    
    Constraints:
    - No loops (for, while) are used.
    - No list/set/dictionary comprehensions.
    """
    input_data = sys.stdin.read().splitlines()
    n = int(input_data.pop(0))  # Read number of test cases
    sum_of_squares(input_data)
    
if __name__ == "__main__":
    main()
